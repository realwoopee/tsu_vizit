import { useEffect, useRef } from "react"
import { Check, FileUp, Trash2, X } from "lucide-react"
import "../styles/dropdown-menu.css"

type UserRole = "student" | "teacher" | "admin"

interface DropdownMenuProps {
  isOpen: boolean
  onClose: () => void
  userRole: UserRole
}

export const DropdownMenu = ({ isOpen, onClose, userRole }: DropdownMenuProps) => {
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isOpen, onClose])

  if (!isOpen) return null

  const handleAction = (action: string) => {
    console.log(`Action: ${action}`)
    onClose()
  }

  const renderMenuItems = () => {
    switch (userRole) {
      case "student":
        return (
          <>
            <button className="dropdown-item" onClick={() => handleAction("attach")}>
              <FileUp size={16} />
              <span>Прикрепить файл</span>
            </button>
            <button className="dropdown-item" onClick={() => handleAction("delete-file")}>
              <Trash2 size={16} />
              <span>Удалить файл</span>
            </button>
          </>
        )
      case "teacher":
        return (
          <>
            <button className="dropdown-item" onClick={() => handleAction("confirm")}>
              <Check size={16} />
              <span>Подтвердить</span>
            </button>
            <button className="dropdown-item" onClick={() => handleAction("reject")}>
              <X size={16} />
              <span>Отклонить</span>
            </button>
          </>
        )
      case "admin":
        return (
          <>
            <button className="dropdown-item" onClick={() => handleAction("confirm")}>
              <Check size={16} />
              <span>Подтвердить</span>
            </button>
            <button className="dropdown-item" onClick={() => handleAction("reject")}>
              <X size={16} />
              <span>Отклонить</span>
            </button>
            <button className="dropdown-item delete" onClick={() => handleAction("delete-record")}>
              <Trash2 size={16} />
              <span>Удалить запись</span>
            </button>
          </>
        )
      default:
        return null
    }
  }

  return (
    <div className="dropdown-menu" ref={menuRef}>
      {renderMenuItems()}
    </div>
  )
}

